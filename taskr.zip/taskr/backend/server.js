const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const JWT_SECRET = process.env.JWT_SECRET || 'taskr-secret-change-in-production';
const PORT = process.env.PORT || 4000;
const DB_PATH = process.env.DB_PATH || '/data/taskr.db';

// Ensure data dir
const dataDir = path.dirname(DB_PATH);
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

// ─── DATABASE ────────────────────────────────────────────────
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    avatar_color TEXT DEFAULT '#6c63ff',
    created_at INTEGER DEFAULT (unixepoch())
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT DEFAULT '',
    priority TEXT DEFAULT 'none',
    status TEXT DEFAULT 'todo',
    due_date TEXT,
    tags TEXT DEFAULT '[]',
    owner_id TEXT REFERENCES users(id),
    assignee_id TEXT REFERENCES users(id),
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch()),
    sort_order INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS subtasks (
    id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    text TEXT NOT NULL,
    done INTEGER DEFAULT 0,
    sort_order INTEGER DEFAULT 0,
    created_at INTEGER DEFAULT (unixepoch())
  );

  CREATE TABLE IF NOT EXISTS comments (
    id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id),
    text TEXT NOT NULL,
    created_at INTEGER DEFAULT (unixepoch())
  );

  CREATE TABLE IF NOT EXISTS activity_log (
    id TEXT PRIMARY KEY,
    task_id TEXT REFERENCES tasks(id) ON DELETE CASCADE,
    user_id TEXT REFERENCES users(id),
    action TEXT NOT NULL,
    meta TEXT DEFAULT '{}',
    created_at INTEGER DEFAULT (unixepoch())
  );
`);

// Seed default users
function seedUsers() {
  const count = db.prepare('SELECT COUNT(*) as c FROM users').get().c;
  if (count > 0) return;
  const users = [
    { id: uid(), username: 'admin', password: bcrypt.hashSync('admin123', 10), name: 'Administrator', role: 'admin', avatar_color: '#6c63ff' },
    { id: uid(), username: 'jan',   password: bcrypt.hashSync('user123', 10),  name: 'Jan Kowalski',  role: 'user',  avatar_color: '#06d6a0' },
    { id: uid(), username: 'anna',  password: bcrypt.hashSync('user123', 10),  name: 'Anna Nowak',   role: 'user',  avatar_color: '#f72585' }
  ];
  const ins = db.prepare('INSERT INTO users (id,username,password,name,role,avatar_color) VALUES (?,?,?,?,?,?)');
  users.forEach(u => ins.run(u.id, u.username, u.password, u.name, u.role, u.avatar_color));

  // Seed demo tasks
  const today = new Date().toISOString().slice(0,10);
  const tomorrow = new Date(Date.now()+86400000).toISOString().slice(0,10);
  const adminId = db.prepare('SELECT id FROM users WHERE username=?').get('admin').id;
  const janId   = db.prepare('SELECT id FROM users WHERE username=?').get('jan').id;
  const annaId  = db.prepare('SELECT id FROM users WHERE username=?').get('anna').id;

  const demoTasks = [
    { id:uid(), title:'Skonfiguruj serwer Proxmox', description:'Zainstaluj i skonfiguruj środowisko wirtualizacji Proxmox VE.', priority:'high', status:'inprog', due_date:tomorrow, tags:'["infrastruktura","serwer"]', owner_id:adminId, assignee_id:janId, sort_order:0 },
    { id:uid(), title:'Zaprojektuj UI aplikacji', description:'Przygotuj makiety i design system dla nowego projektu.', priority:'med', status:'done', due_date:today, tags:'["design","ui"]', owner_id:adminId, assignee_id:annaId, sort_order:0 },
    { id:uid(), title:'Wdrożyć kontener Docker', description:'Zbuduj i opublikuj obraz aplikacji w rejestrze.', priority:'high', status:'todo', due_date:tomorrow, tags:'["backend","docker"]', owner_id:janId, assignee_id:janId, sort_order:1 },
    { id:uid(), title:'Dokumentacja API', description:'Opisz wszystkie endpointy REST z przykładami.', priority:'low', status:'todo', due_date:null, tags:'["dokumentacja"]', owner_id:annaId, assignee_id:null, sort_order:2 },
    { id:uid(), title:'Code review modułu auth', description:'', priority:'med', status:'review', due_date:tomorrow, tags:'["backend","security"]', owner_id:adminId, assignee_id:annaId, sort_order:0 }
  ];

  const insT = db.prepare('INSERT INTO tasks (id,title,description,priority,status,due_date,tags,owner_id,assignee_id,sort_order) VALUES (?,?,?,?,?,?,?,?,?,?)');
  demoTasks.forEach(t => insT.run(t.id,t.title,t.description,t.priority,t.status,t.due_date,t.tags,t.owner_id,t.assignee_id,t.sort_order));

  // Subtasks for first task
  const firstId = demoTasks[0].id;
  const insS = db.prepare('INSERT INTO subtasks (id,task_id,text,done,sort_order) VALUES (?,?,?,?,?)');
  insS.run(uid(), firstId, 'Zainstaluj Proxmox VE', 1, 0);
  insS.run(uid(), firstId, 'Skonfiguruj sieć bridged', 1, 1);
  insS.run(uid(), firstId, 'Utwórz pierwsze VM', 0, 2);
  insS.run(uid(), firstId, 'Backup konfiguracji', 0, 3);
}
seedUsers();

// ─── HELPERS ─────────────────────────────────────────────────
function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2); }

function auth(req, res, next) {
  const h = req.headers.authorization;
  if (!h || !h.startsWith('Bearer ')) return res.status(401).json({ error: 'Unauthorized' });
  try {
    req.user = jwt.verify(h.slice(7), JWT_SECRET);
    next();
  } catch { res.status(401).json({ error: 'Invalid token' }); }
}

function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
  next();
}

function broadcast(data, excludeWs = null) {
  const msg = JSON.stringify(data);
  wss.clients.forEach(ws => {
    if (ws !== excludeWs && ws.readyState === WebSocket.OPEN) ws.send(msg);
  });
}

function broadcastAll(data) {
  const msg = JSON.stringify(data);
  wss.clients.forEach(ws => { if (ws.readyState === WebSocket.OPEN) ws.send(msg); });
}

function logActivity(task_id, user_id, action, meta = {}) {
  db.prepare('INSERT INTO activity_log (id,task_id,user_id,action,meta) VALUES (?,?,?,?,?)')
    .run(uid(), task_id, user_id, action, JSON.stringify(meta));
}

function fullTask(id) {
  const task = db.prepare('SELECT * FROM tasks WHERE id=?').get(id);
  if (!task) return null;
  task.tags = JSON.parse(task.tags || '[]');
  task.subtasks = db.prepare('SELECT * FROM subtasks WHERE task_id=? ORDER BY sort_order').all(id);
  task.comments = db.prepare(`
    SELECT c.*, u.name as user_name, u.avatar_color
    FROM comments c JOIN users u ON c.user_id=u.id
    WHERE c.task_id=? ORDER BY c.created_at
  `).all(id);
  task.assignee = task.assignee_id ? db.prepare('SELECT id,name,avatar_color FROM users WHERE id=?').get(task.assignee_id) : null;
  task.owner = task.owner_id ? db.prepare('SELECT id,name,avatar_color FROM users WHERE id=?').get(task.owner_id) : null;
  task.done = task.status === 'done';
  return task;
}

// ─── MIDDLEWARE ───────────────────────────────────────────────
app.use(cors());
app.use(express.json());

// ─── AUTH ROUTES ─────────────────────────────────────────────
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE username=?').get(username?.toLowerCase().trim());
  if (!user || !bcrypt.compareSync(password, user.password))
    return res.status(401).json({ error: 'Nieprawidłowy użytkownik lub hasło' });
  const token = jwt.sign({ id: user.id, username: user.username, role: user.role, name: user.name }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, username: user.username, name: user.name, role: user.role, avatar_color: user.avatar_color } });
});

app.post('/api/auth/change-password', auth, (req, res) => {
  const { current_password, new_password } = req.body;
  if (!new_password || new_password.length < 4) return res.status(400).json({ error: 'Hasło min. 4 znaki' });
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  if (!bcrypt.compareSync(current_password, user.password))
    return res.status(400).json({ error: 'Aktualne hasło nieprawidłowe' });
  db.prepare('UPDATE users SET password=? WHERE id=?').run(bcrypt.hashSync(new_password, 10), req.user.id);
  res.json({ ok: true });
});

app.get('/api/auth/me', auth, (req, res) => {
  const user = db.prepare('SELECT id,username,name,role,avatar_color FROM users WHERE id=?').get(req.user.id);
  res.json(user);
});

// ─── USER ROUTES ─────────────────────────────────────────────
app.get('/api/users', auth, (req, res) => {
  res.json(db.prepare('SELECT id,username,name,role,avatar_color,created_at FROM users ORDER BY name').all());
});

app.post('/api/users', auth, adminOnly, (req, res) => {
  const { username, password, name, role } = req.body;
  if (!username || !password || !name) return res.status(400).json({ error: 'Wymagane: username, password, name' });
  if (db.prepare('SELECT id FROM users WHERE username=?').get(username.toLowerCase()))
    return res.status(400).json({ error: 'Taki użytkownik już istnieje' });
  const colors = ['#6c63ff','#06d6a0','#f72585','#4cc9f0','#ffd166','#ff6b6b'];
  const color = colors[Math.floor(Math.random() * colors.length)];
  const id = uid();
  db.prepare('INSERT INTO users (id,username,password,name,role,avatar_color) VALUES (?,?,?,?,?,?)')
    .run(id, username.toLowerCase(), bcrypt.hashSync(password, 10), name, role || 'user', color);
  broadcastAll({ type: 'users_updated' });
  res.json({ ok: true, id });
});

app.put('/api/users/:id', auth, (req, res) => {
  const targetId = req.params.id;
  if (req.user.role !== 'admin' && req.user.id !== targetId)
    return res.status(403).json({ error: 'Brak dostępu' });
  const { name, role, avatar_color, password } = req.body;
  const updates = [];
  const vals = [];
  if (name) { updates.push('name=?'); vals.push(name); }
  if (role && req.user.role === 'admin') { updates.push('role=?'); vals.push(role); }
  if (avatar_color) { updates.push('avatar_color=?'); vals.push(avatar_color); }
  if (password) {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Użyj change-password' });
    updates.push('password=?'); vals.push(bcrypt.hashSync(password, 10));
  }
  if (!updates.length) return res.status(400).json({ error: 'Nic do zmiany' });
  vals.push(targetId);
  db.prepare(`UPDATE users SET ${updates.join(',')} WHERE id=?`).run(...vals);
  broadcastAll({ type: 'users_updated' });
  res.json({ ok: true });
});

app.delete('/api/users/:id', auth, adminOnly, (req, res) => {
  if (req.params.id === req.user.id) return res.status(400).json({ error: 'Nie możesz usunąć siebie' });
  db.prepare('DELETE FROM users WHERE id=?').run(req.params.id);
  broadcastAll({ type: 'users_updated' });
  res.json({ ok: true });
});

// ─── TASK ROUTES ─────────────────────────────────────────────
app.get('/api/tasks', auth, (req, res) => {
  let rows;
  if (req.user.role === 'admin') {
    rows = db.prepare('SELECT * FROM tasks ORDER BY sort_order, created_at DESC').all();
  } else {
    rows = db.prepare('SELECT * FROM tasks WHERE owner_id=? OR assignee_id=? ORDER BY sort_order, created_at DESC').all(req.user.id, req.user.id);
  }
  const tasks = rows.map(t => {
    t.tags = JSON.parse(t.tags || '[]');
    t.subtasks = db.prepare('SELECT * FROM subtasks WHERE task_id=? ORDER BY sort_order').all(t.id);
    t.assignee = t.assignee_id ? db.prepare('SELECT id,name,avatar_color FROM users WHERE id=?').get(t.assignee_id) : null;
    t.owner = t.owner_id ? db.prepare('SELECT id,name,avatar_color FROM users WHERE id=?').get(t.owner_id) : null;
    t.done = t.status === 'done';
    t.comment_count = db.prepare('SELECT COUNT(*) as c FROM comments WHERE task_id=?').get(t.id).c;
    return t;
  });
  res.json(tasks);
});

app.post('/api/tasks', auth, (req, res) => {
  const { title, description, priority, status, due_date, tags, assignee_id } = req.body;
  if (!title) return res.status(400).json({ error: 'Tytuł wymagany' });
  const maxOrder = db.prepare('SELECT MAX(sort_order) as m FROM tasks').get().m || 0;
  const id = uid();
  db.prepare('INSERT INTO tasks (id,title,description,priority,status,due_date,tags,owner_id,assignee_id,sort_order) VALUES (?,?,?,?,?,?,?,?,?,?)')
    .run(id, title, description||'', priority||'none', status||'todo', due_date||null, JSON.stringify(tags||[]), req.user.id, assignee_id||null, maxOrder+1);
  logActivity(id, req.user.id, 'created', { title });
  const task = fullTask(id);
  broadcastAll({ type: 'task_created', task });
  res.json(task);
});

app.get('/api/tasks/:id', auth, (req, res) => {
  const t = fullTask(req.params.id);
  if (!t) return res.status(404).json({ error: 'Not found' });
  res.json(t);
});

app.put('/api/tasks/:id', auth, (req, res) => {
  const old = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.params.id);
  if (!old) return res.status(404).json({ error: 'Not found' });
  const fields = ['title','description','priority','status','due_date','assignee_id'];
  const updates = []; const vals = [];
  fields.forEach(f => {
    if (req.body[f] !== undefined) { updates.push(`${f}=?`); vals.push(req.body[f]); }
  });
  if (req.body.tags !== undefined) { updates.push('tags=?'); vals.push(JSON.stringify(req.body.tags)); }
  updates.push('updated_at=?'); vals.push(Math.floor(Date.now()/1000));
  vals.push(req.params.id);
  db.prepare(`UPDATE tasks SET ${updates.join(',')} WHERE id=?`).run(...vals);

  if (req.body.status && req.body.status !== old.status)
    logActivity(req.params.id, req.user.id, 'status_changed', { from: old.status, to: req.body.status });
  if (req.body.assignee_id !== undefined && req.body.assignee_id !== old.assignee_id)
    logActivity(req.params.id, req.user.id, 'assigned', { assignee_id: req.body.assignee_id });

  const task = fullTask(req.params.id);
  broadcastAll({ type: 'task_updated', task });
  res.json(task);
});

app.delete('/api/tasks/:id', auth, (req, res) => {
  const t = db.prepare('SELECT * FROM tasks WHERE id=?').get(req.params.id);
  if (!t) return res.status(404).json({ error: 'Not found' });
  if (req.user.role !== 'admin' && t.owner_id !== req.user.id)
    return res.status(403).json({ error: 'Brak dostępu' });
  db.prepare('DELETE FROM tasks WHERE id=?').run(req.params.id);
  broadcastAll({ type: 'task_deleted', id: req.params.id });
  res.json({ ok: true });
});

// Reorder (Kanban drag & drop)
app.post('/api/tasks/reorder', auth, (req, res) => {
  const { updates } = req.body; // [{id, status, sort_order}]
  const stmt = db.prepare('UPDATE tasks SET status=?, sort_order=?, updated_at=? WHERE id=?');
  const now = Math.floor(Date.now()/1000);
  db.transaction(() => updates.forEach(u => stmt.run(u.status, u.sort_order, now, u.id)))();
  broadcastAll({ type: 'tasks_reordered', updates });
  res.json({ ok: true });
});

// ─── SUBTASK ROUTES ───────────────────────────────────────────
app.post('/api/tasks/:id/subtasks', auth, (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: 'Text required' });
  const max = db.prepare('SELECT MAX(sort_order) as m FROM subtasks WHERE task_id=?').get(req.params.id).m || 0;
  const id = uid();
  db.prepare('INSERT INTO subtasks (id,task_id,text,done,sort_order) VALUES (?,?,?,?,?)').run(id, req.params.id, text, 0, max+1);
  const task = fullTask(req.params.id);
  broadcastAll({ type: 'task_updated', task });
  res.json(task);
});

app.put('/api/tasks/:id/subtasks/:sid', auth, (req, res) => {
  const { done, text } = req.body;
  const updates = []; const vals = [];
  if (done !== undefined) { updates.push('done=?'); vals.push(done ? 1 : 0); }
  if (text !== undefined) { updates.push('text=?'); vals.push(text); }
  if (!updates.length) return res.status(400).json({ error: 'Nothing to update' });
  vals.push(req.params.sid);
  db.prepare(`UPDATE subtasks SET ${updates.join(',')} WHERE id=?`).run(...vals);
  db.prepare('UPDATE tasks SET updated_at=? WHERE id=?').run(Math.floor(Date.now()/1000), req.params.id);
  const task = fullTask(req.params.id);
  broadcastAll({ type: 'task_updated', task });
  res.json(task);
});

app.delete('/api/tasks/:id/subtasks/:sid', auth, (req, res) => {
  db.prepare('DELETE FROM subtasks WHERE id=?').run(req.params.sid);
  const task = fullTask(req.params.id);
  broadcastAll({ type: 'task_updated', task });
  res.json(task);
});

// ─── COMMENTS ────────────────────────────────────────────────
app.get('/api/tasks/:id/comments', auth, (req, res) => {
  res.json(db.prepare(`
    SELECT c.*, u.name as user_name, u.avatar_color
    FROM comments c JOIN users u ON c.user_id=u.id
    WHERE c.task_id=? ORDER BY c.created_at
  `).all(req.params.id));
});

app.post('/api/tasks/:id/comments', auth, (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: 'Text required' });
  const id = uid();
  db.prepare('INSERT INTO comments (id,task_id,user_id,text) VALUES (?,?,?,?)').run(id, req.params.id, req.user.id, text);
  logActivity(req.params.id, req.user.id, 'commented', { preview: text.slice(0,60) });
  const task = fullTask(req.params.id);
  broadcastAll({ type: 'task_updated', task });
  res.json(task);
});

// ─── ACTIVITY ────────────────────────────────────────────────
app.get('/api/tasks/:id/activity', auth, (req, res) => {
  res.json(db.prepare(`
    SELECT a.*, u.name as user_name, u.avatar_color
    FROM activity_log a LEFT JOIN users u ON a.user_id=u.id
    WHERE a.task_id=? ORDER BY a.created_at DESC LIMIT 50
  `).all(req.params.id));
});

app.get('/api/activity', auth, (req, res) => {
  const rows = db.prepare(`
    SELECT a.*, u.name as user_name, u.avatar_color, t.title as task_title
    FROM activity_log a 
    LEFT JOIN users u ON a.user_id=u.id
    LEFT JOIN tasks t ON a.task_id=t.id
    ORDER BY a.created_at DESC LIMIT 30
  `).all();
  res.json(rows.map(r => ({ ...r, meta: JSON.parse(r.meta||'{}') })));
});

// ─── STATS ───────────────────────────────────────────────────
app.get('/api/stats', auth, (req, res) => {
  const isAdmin = req.user.role === 'admin';
  const uid_filter = req.user.id;
  const total = isAdmin
    ? db.prepare('SELECT COUNT(*) as c FROM tasks').get().c
    : db.prepare('SELECT COUNT(*) as c FROM tasks WHERE owner_id=? OR assignee_id=?').get(uid_filter, uid_filter).c;
  const done = isAdmin
    ? db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status='done'").get().c
    : db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status='done' AND (owner_id=? OR assignee_id=?)").get(uid_filter, uid_filter).c;
  const inprog = isAdmin
    ? db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status='inprog'").get().c
    : db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status='inprog' AND (owner_id=? OR assignee_id=?)").get(uid_filter, uid_filter).c;
  const overdue = isAdmin
    ? db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status!='done' AND due_date IS NOT NULL AND due_date < date('now')").get().c
    : db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status!='done' AND due_date IS NOT NULL AND due_date < date('now') AND (owner_id=? OR assignee_id=?)").get(uid_filter, uid_filter).c;
  res.json({ total, done, inprog, overdue });
});

// ─── WEBSOCKET ────────────────────────────────────────────────
wss.on('connection', (ws, req) => {
  ws.on('message', msg => {
    try {
      const data = JSON.parse(msg);
      if (data.type === 'ping') ws.send(JSON.stringify({ type: 'pong' }));
    } catch {}
  });
  ws.send(JSON.stringify({ type: 'connected' }));
});

server.listen(PORT, () => console.log(`Taskr backend running on port ${PORT}`));
